$(function() {
    loadData()
});

function updateViewGames(data) {
console.log(data)
document.getElementById("MessageToLogin").setAttribute("style","display:none");
  var htmlListGames = data.games.map(function (game) {
      return  '<li class="list-group-item">' + new Date(game.created).toLocaleString() + ' | <br> ' + game.gamePlayers.map(function(element) { return element.player.email}).join(', ')  +'</li>';
  }).join('');
    document.getElementById("game-list").innerHTML = htmlListGames;

   var htmlListGamesOwn = data.gamesOwn.map(function (game) {
         return  '<li class="list-group-item">' + new Date(game.joinGame).toLocaleString() /*+ ' | <br> ' + game.map(function(element) { return element.player.email}).join(', ') */ +'</li>';
     }).join('');
  document.getElementById("game-list-own").innerHTML = htmlListGamesOwn;
}

function updateViewLBoard(data) {
  var htmlList = data.map(function (score) {
      return  '<tr><td>' + score.email + '</td>'
              + '<td>' + score.scores.total + '</td>'
              + '<td>' + score.scores.won + '</td>'
              + '<td>' + score.scores.lost + '</td>'
              + '<td>' + score.scores.tied + '</td></tr>';
  }).join('');
  document.getElementById("leader-list").innerHTML = htmlList;
}

function loadData() {
  $.get("http://localhost:8080/api/games")
    .done(function(data) {
      updateViewGames(data);
    })
    .fail(function( jqXHR, textStatus ) {
    //  alert( "Failed: " + textStatus );
    });

  $.get("http://localhost:8080/api/leaderBoard")
    .done(function(data) {
      updateViewLBoard(data);
    })
    .fail(function( jqXHR, textStatus ) {
      alert( "Failed: " + textStatus );
    });
}

/*formulario de login*/
var btnLogin = document.getElementById("btnLogin")
btnLogin.addEventListener("click",function(){
let nameUsu = document.getElementById("inpEmail").value
let passwordUsu = document.getElementById("inpPassword").value
loginFunc(nameUsu,passwordUsu)
})

var btnLogout =document.getElementById("btnLogout")
btnLogout.addEventListener("click",function(){
$.post("/api/logout").done(function() { console.log("logged out");
 location.reload();})
})

var btnLogUp =document.getElementById("btnLogUp")
btnLogUp.addEventListener("click",function(){
let nameUsu = document.getElementById("inpEmail").value
let passwordUsu = document.getElementById("inpPassword").value
$.post("/api/players",{email: nameUsu, password: passwordUsu}).done(function() {
console.log(" Successed LogUP!"); }).fail(function( jqXHR, textStatus ) {

                                          alert( "Failed: " + jqXHR.responseText );
                                        });
})

function loginFunc (nameUsu,passwordUsu){
$.ajax({
type: 'POST',
url:'/api/login',
data: {name: nameUsu, password: passwordUsu},
success: function(){
console.log("login!")
$.get("http://localhost:8080/web/games.html")
loadData();
document.getElementById("btnLogin").setAttribute("style","display:none")
document.getElementById("btnLogUp").setAttribute("style","display:none")
document.getElementById("btnLogout").setAttribute("style","display:inline")},
 error: function(data) {
      alert("No se ha podido obtener la información, compruebe sus datos de acceso")
      alert(data.responseJSON.error)}
}
)

}


/*
Codigo anterior
$(function(){
    var listGames = $("ol")
    var games = $.getJSON({
        url:"http://localhost:8080/api/games",
        })
        .done(function (data)
            {
            data.map(function(data)
                {
                let date = new Date(data.created).toLocaleString()
                var arrGame = []
                arrGame.push(date)
                for (let i = 0; i < data.gamePlayers.length; i++){
                let email = data.gamePlayers[i].player.player
                arrGame.push(email)
                }
                listGames.append(
                '<li>' + arrGame + '</li>'
                )})
            }
            )}
)*/
