/*package com.codeoftheweb.salvo;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

public class Salvo {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO,generator = "native")
  @GenericGenerator(name="native",strategy = "native")
private long id;

  private int turn;

  @ElementCollection
  @Column(name="salvoLocation")
  private Set<String> salvoLocations;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "gamePlayer_id")
  private GamePlayer gamePlayer;

  public Salvo(){

  }

  public Salvo(int turn, Set<String> salvoLocations, GamePlayer gamePlayer){

  }

}*/
