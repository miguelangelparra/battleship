/*package com.codeoftheweb.salvo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SalvoRepository extends JpaRepository<Salvo,Long> {
}
*/