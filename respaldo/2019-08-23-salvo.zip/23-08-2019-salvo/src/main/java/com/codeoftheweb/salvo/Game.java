package com.codeoftheweb.salvo;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Entity
public class Game {
@Id
    @GeneratedValue(strategy = GenerationType.AUTO,generator = "native")
    @GenericGenerator(name="native", strategy = "native")
    private long id;
    private Date dateGame;

    @OneToMany(mappedBy="game", fetch=FetchType.EAGER)
    List<GamePlayer> gamePlayers;

public Game(){

    this.dateGame = new Date();
}

public Game(Date date){
    this.dateGame = date;

}
    public long getId() {
        return id;
    }
    public Date getDateGame() {
        return dateGame;
    }


    public List<GamePlayer> getGamePlayers() {
        return gamePlayers;
    }

    public void setGamePlayers(List<GamePlayer> gamePlayers) {
        this.gamePlayers = gamePlayers;
    }

    public void setDateGame(Date dateGame) {
        this.dateGame = dateGame;
    }
}
