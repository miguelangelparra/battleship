package com.codeoftheweb.salvo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.Instant;
import java.util.Date;


@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(GameRepository gameRepository, PlayerRepository playerRepository, GamePlayerRepository gamePlayerRepository) {
		return (args) -> {

			Player player1 = new Player("Jack", "Bauer", "j.bauer", "j.bauer@ctu.gov");
			Player player2 = new Player("Chloe", "O'Brian", "C.Brian", "chloe@ctu.gov");
			Player player3 = new Player("Kim", "Bauer", "K.Bauer", "a.Bauer@ctu.gov");
			Player player4 = new Player("David", "Palmer", "PalmerPalmer", "d.palmer@gmail.com");
			Player player5 = new Player("Tonny", "Almeida", "AlmeidaTon", "almeida@gmail.com");

			playerRepository.save(player1);
			playerRepository.save(player2);
			playerRepository.save(player3);
			playerRepository.save(player4);
			playerRepository.save(player5);


			Date date = new Date();
			Instant unaHoraMas = date.toInstant().plusSeconds(3600);
			Instant dosHoraMas = date.toInstant().plusSeconds(7200);

			Game game1 = new Game();
			Game game2 = new Game(Date.from((unaHoraMas)));
			Game game3 = new Game(Date.from((dosHoraMas)));

			gameRepository.save(game1);
			gameRepository.save(game2);
			gameRepository.save(game3);

			GamePlayer gamePlayer1 = new GamePlayer(date, player1, game1);
			GamePlayer gamePlayer2 = new GamePlayer(date,player2,game2);
			GamePlayer gamePlayer3 = new GamePlayer(date,player3,game3);
			GamePlayer gamePlayer4 = new GamePlayer(date,player4,game1);
			GamePlayer gamePlayer5 = new GamePlayer(date,player5,game2);

			gamePlayerRepository.save(gamePlayer1);
			gamePlayerRepository.save(gamePlayer2);
			gamePlayerRepository.save(gamePlayer3);
			gamePlayerRepository.save(gamePlayer4);
			gamePlayerRepository.save(gamePlayer5);

		};
	}
}

