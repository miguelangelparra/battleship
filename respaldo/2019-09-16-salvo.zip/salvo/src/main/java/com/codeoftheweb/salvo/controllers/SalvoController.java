package com.codeoftheweb.salvo.controllers;
import com.codeoftheweb.salvo.models.GamePlayer;
import com.codeoftheweb.salvo.repositories.GamePlayerRepository;
import com.codeoftheweb.salvo.repositories.GameRepository;
import com.codeoftheweb.salvo.repositories.PlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")

public class    SalvoController {

    @Autowired
    private GameRepository repoGame;

    @Autowired
    private GamePlayerRepository repoGamePlayer;

    @Autowired
    private PlayerRepository playerRepository;

    @RequestMapping("/games")
    public List<Map<String,Object>> infoGame(){
        return repoGame.findAll().stream()
                .map(game -> game.getGameDTO())
                .collect(Collectors.toList());

        //return repo.findAll().stream().map(game -> game.getId()).collect(Collectors.toList()); Para pedir solo el ID
    };

    @RequestMapping("/leaderBoard")
    public  List<Map<String,Object>> leaderBoard(){
        return  playerRepository.findAll()
          .stream()
          .map(player  ->  player.makePlayerScoreDTO())
          .collect(Collectors.toList());
    }

    @RequestMapping("/game_view/{idGamePlayer}")
    public Map<String,Object> game(@PathVariable Long idGamePlayer){
        return gameViewDTO(repoGamePlayer.findById(idGamePlayer).get());
    }

    private Map<String,Object> gameViewDTO(GamePlayer gamePlayer)
    {
        Map<String,Object> dto = new LinkedHashMap<>();

        dto.put("id",gamePlayer.getId());
        dto.put("created",gamePlayer.getJoinGame());
        dto.put("gamePlayers", gamePlayer.getGame().getGamePlayers()
        .stream()
        .map(gP -> gP.makeGamePlayerDTO()));

        dto.put("ships", gamePlayer.getShips()
        .stream()
        .map(sh -> sh.makeShipDTO()));

        dto.put("salvoes",gamePlayer.getSalvoes()
        .stream()
        .flatMap((gP -> gamePlayer.getSalvoes()
        .stream()
        .map(salvo -> salvo.makeSalvoDTO()))));

        return dto;
    }








}

